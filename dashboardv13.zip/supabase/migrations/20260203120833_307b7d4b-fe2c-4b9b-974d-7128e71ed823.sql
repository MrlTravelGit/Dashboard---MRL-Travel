-- Add observation field to employees table
ALTER TABLE public.employees
ADD COLUMN observation TEXT;