import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { BookingProvider } from "./contexts/BookingContext";
import HomePage from "./pages/HomePage";
import FlightsPage from "./pages/FlightsPage";
import HotelsPage from "./pages/HotelsPage";
import CarRentalsPage from "./pages/CarRentalsPage";
import BookingDetailsPage from "./pages/BookingDetailsPage";
import BookingsPage from "./pages/BookingsPage";
import CompaniesPage from "./pages/CompaniesPage";
import EmployeesPage from "./pages/EmployeesPage";
import LoginPage from "./pages/LoginPage";
import NotFound from "./pages/NotFound";
import { LoadingGate } from "@/components/LoadingGate";

const queryClient = new QueryClient();

// Protected route component - bloqueia se não autenticado
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading, isLoadingRole, authReady } = useAuth();

  // Aguarda carregar session e role, mas nunca fica preso se authReady está true
  if (!authReady || isLoading || isLoadingRole) {
    return <LoadingGate label="Carregando..." />;
  }

  // Após loading, se não autenticado, redireciona
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

// Admin route component - bloqueia se não é admin
// Aguarda role estar carregada antes de redirecionar
function AdminRoute({ children }: { children: React.ReactNode }) {
  const { isAdmin, appRole, isLoadingRole, authReady } = useAuth();

  // Aguarda role estar carregada, mas nunca fica preso se authReady está true
  if (!authReady || isLoadingRole) {
    return <LoadingGate label="Carregando permissões..." />;
  }

  // Após role estar carregada, verifica se é admin
  const isUserAdmin = isAdmin || appRole === "admin";
  if (!isUserAdmin) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}



// App routes with auth context available
function AppRoutes() {
  // Remove duplicated loading logic here, rely on ProtectedRoute
  const { user } = useAuth();

  return (
    <Routes>
      <Route 
        path="/login" 
        element={user ? <Navigate to="/" replace /> : <LoginPage />} 
      />
      <Route path="/" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
      <Route path="/reservas" element={<ProtectedRoute><BookingsPage /></ProtectedRoute>} />
      <Route path="/reservas/:id" element={<ProtectedRoute><BookingDetailsPage /></ProtectedRoute>} />
      <Route path="/voos" element={<ProtectedRoute><FlightsPage /></ProtectedRoute>} />
      <Route path="/hospedagens" element={<ProtectedRoute><HotelsPage /></ProtectedRoute>} />
      <Route path="/aluguel-carro" element={<ProtectedRoute><CarRentalsPage /></ProtectedRoute>} />
      <Route path="/empresas" element={<ProtectedRoute><AdminRoute><CompaniesPage /></AdminRoute></ProtectedRoute>} />
      {/* Usuários de empresa também devem acessar a aba de Funcionários, porém com filtro por company_id */}
      <Route path="/funcionarios" element={<ProtectedRoute><EmployeesPage /></ProtectedRoute>} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <TooltipProvider>
        <AuthProvider>
          <BookingProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <AppRoutes />
            </BrowserRouter>
          </BookingProvider>
        </AuthProvider>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
